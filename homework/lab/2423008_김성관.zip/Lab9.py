# -10 ~ -110 까지 -10 감소하는 숫자 출력
for vlaue in range(-10, -101, -10):
    print(vlaue)


