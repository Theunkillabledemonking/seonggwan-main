
num = int(input("N을 입력해:"))

for i in range(1, num+1):
    print('*' * i)
    
for i in range(num-1,0,-1):
    print('*'*i)