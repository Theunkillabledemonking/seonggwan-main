# 사용자 값 정수를 입력
input_Value1 = int(input("첫 번째 숫자(정수)를 입력하세요:"))
# 사용자 실수를 입력 받기
input_Value2 = float(input("두 번째 숫자(부동 소수점 수)를 입력하세요: "))
# 두 값의 합이 100을 초과하는지 체크

# 묵시적 형변환을 이용함
sum = input_Value1 + input_Value2

if 100 > sum:
    print("합이 100 이하입니다.", sum)
else:
    print("합이 100을 초과합니다.: ", sum)
