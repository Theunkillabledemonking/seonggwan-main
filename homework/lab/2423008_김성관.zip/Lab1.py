# while 을 사용하여 별을 직각삼각형으로 출력

count = 0

while True:
    count += 1
    
    if count > 5: 
        break
    
    print("*" * count)